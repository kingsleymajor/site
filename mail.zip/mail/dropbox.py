from tkinter import *
root = Tk()
root.title("major drop")
root.geometry("400x400")

to_do_list=[["go to farm"],["play ball"],["go church"],["eat food"],["cook food"],["drink wine"],["drive car"]]
def show():
    if clicked.get()=="monday":
        mylabel=Label(root,text=to_do_list[0]).pack()
    elif clicked.get()=="tuesday":
        mylabel=Label(root,text=to_do_list[1]).pack()

list = [
    "monday",
    "tuesday",
    "wednesday",
    "thursday",        
    "friday",
    "saturday",
    "sunday"
]

clicked=StringVar()
clicked.set(list[0])
#with list
drop =OptionMenu(root,clicked,*list) 
#without list
#drop =OptionMenu(root,clicked,"monday","tuesday","wednesday","thursday","friday") 
drop.pack()

button=Button(root,text="show selection",command=show).pack()

root.mainloop()
