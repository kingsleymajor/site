from tkinter import *

root = Tk()
root.title("Learn coding")
root.iconbitmap('')

my_img=imagetk

root.mainloop()
