name = input("Enter your name:")
age = int(input("what is your age?:"))
country = input("where is your country?:")
if name == "messi" and age<50 and country == "argentina":
    print ("you are a baller for life,i bu ezigbote odogwu")
elif name == "Ronaldo":
    print ("go and train more son") 


    

