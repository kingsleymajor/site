from django.contrib import admin
from .models import questions,choice

admin.site.site_header="pollster Admin"
admin.site.site_title="pollster Admin Area"
admin.site.index_title="Welcome to the pollster Admin Area"

class ChoiceInline(admin.TabularInline):
    model=choice
    extra=3

class questionAdmin(admin.ModelAdmin):
    fieldsets=[(None,{'fields':['question_text']}),
    ('Date information',{'fields':['pub_date'],'classes':['collapse']}),]
    inlines=[ChoiceInline]


#admin .site.register(questions)
#admin.site.register(choice,ChoiceInline)
admin.site.register(questions,questionAdmin)


