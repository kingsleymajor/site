from django.shortcuts import render

from .models import questions,choice

def index(request):
    latest_question_list=questions.objects.order_by('-pub_date')[:5]
    #context={'latest_question_list':latest_question_list}
    return render(request,'polls/index.html',{'latest_question_list':latest_question_list})
