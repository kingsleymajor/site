class  goat:
    def __init__(self,complexion,height,smell,taste)
    self.complexion = complexion
    