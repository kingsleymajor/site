from django.shortcuts import render
from django.http import HttpRequest, HttpResponse

def hi(request):
    return HttpRequest('<<h1>this is my home page</h1>')
# Create your views here.
