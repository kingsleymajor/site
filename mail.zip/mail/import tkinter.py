from tkinter import *

root=Tk()
root.title("learn coding")





root.mainloop()
