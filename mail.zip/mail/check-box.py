from cProfile import label
from tkinter import *
root = Tk()
root.title("major check")
root.geometry("400x400")

def show():
    mylabel=Label(root,text=var.get()).pack()
    
var = StringVar()
c = Checkbutton(root, text="checkbox", variable=var,onvalue="on",offvalue="off")
c.deselect()
c.pack()
mylabel=Label(root,text=var.get()).pack()
MYBUTTON=Button(root,text="show selection",command=show).pack()

root.mainloop()
