from asyncio.windows_events import NULL
from tkinter import *
root=Tk()
root.title("Login space")
root.geometry("400x400")
tit_label=Label(root,text="Log-in")
tit_label.grid(row=0,column=3)

def work():
        if pass_box.get()=="8587" and user_box.get()=="kings":
                label=Label(root,text="     log_in succesful!",fg="green")
                label.grid(row=1,column=3)
        elif pass_box.get()!=8587 or user_box.get()!="kings":
                label=Label(root,text="wrong password or username!",fg="red")
                label.grid(row=1,column=3)
        elif pass_box.get() == NULL or user_box.get()==NULL:
                label=Label(root,text="fill required fields!",fg="red")
                label.grid(row=1,column=3)
        

pass_box=Entry(root,width=45)
pass_box.grid(row=2,column=3)

user_box=Entry(root,width=45)
user_box.grid(row=3,column=3,pady=10)


user_label=Label(root,text="Enter username:")
user_label.grid(row=3,column=0)
pass_label=Label(root,text="Enter password:")
pass_label.grid(row=2,column=0)
pop_label=Label(root,text="Forgot password?",fg="green")
pop_label.grid(row=4,column=3)

log_button=Button(root,text="OK",bg="green",command=work)
log_button.grid(row=5,column=3,columnspan=4,ipadx=100)





root.mainloop()