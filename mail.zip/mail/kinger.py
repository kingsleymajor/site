major = int(input("enter your age:"))
while major <= 30:
    print(major)
    major += 2
print ("loop don finish")       