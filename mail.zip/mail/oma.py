from tkinter import *
root = Tk()
e=Entry(root)
e.grid()
e.insert(0,"enter sth: ")
def myclick():

    label = Label(root, text="hello " + e.get())
    label.grid()
button = Button(root,text="+",command=myclick,fg="white",bg="blue")
button.grid(row=2,column=3)
root.mainloop()
