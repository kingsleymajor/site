from http.client import HTTPResponse
from django.shortcuts import render
from django.http import HTTPResponse



def say_hello(request):
    return HTTPResponse('hello world')


# Create your views here.
