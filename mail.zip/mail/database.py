from tkinter import *
import sqlite3

root=Tk()
root.title("major data")
root.geometry("400x400")

#create a database or connect to one
conn=sqlite3.connect('address_book.db')

#create a cursor
c=conn.cursor()

#create table
# c.execute("""CREATE TABLE kings(
#     first_name text,
#     last_name text,
#     address text,
#     city text,
#     zipcode integer
#     )""")

#create function to delete a record
def delete():
    #create a database or connect to one
    conn=sqlite3.connect('address_book.db')

    #create a cursor
    c=conn.cursor()

    #delete a record
    c.execute("DELETE from addresses WHERE oid=PLACEHOLDER")
       #commit changes
    conn.commit()
    #close connection
    conn.close()


#create submit function for database
def submit():
    #create a database or connect to one
    conn=sqlite3.connect('address_book.db')
    #create a cursor
    c=conn.cursor()
    #insert into table
    c.execute("INSERT INTO addresses VALUES(:f_name,:l_name,:address,:city,:zipcode)",
        {
            'f_name': f_name.get(),
            'l_name': l_name.get(),
            'address': address.get(),
            'city': city.get(),
            'zipcode': zipcode.get()
        })

    #commit changes
    conn.commit()

    #close connection
    conn.close()


    #clear text box
    f_name.delete(0,END)
    l_name.delete(0,END)
    address.delete(0,END)
    city.delete(0,END)
    state.delete(0,END)
    zipcode.delete(0,END)

#create query function

def query():
     #create a database or connect to one
    conn=sqlite3.connect('address_book.db')

    #create a cursor
    c=conn.cursor()
    #quer the data base
    c.execute("SELECT*,oid FROM addresses")
    records=c.fetchall()
    #print(records)

    #loop through results
    print_records=''
    for record in records:
        print_records +=str(record[0]) +"\n"
    query_label=Label(root,text=print_records)
    query_label.grid(row=8,column=0,columnspan=2)

    #commit changes
    conn.commit()

    #close connection
    conn.close()



#create text boxes
f_name=Entry(root,width=30)
f_name.grid(row=0,column=1,padx=20)

l_name=Entry(root,width=30)
l_name.grid(row=1,column=1)

address=Entry(root,width=30)
address.grid(row=2,column=1)

city=Entry(root,width=30)
city.grid(row=3,column=1)

state=Entry(root,width=30)
state.grid(row=4,column=1)

zipcode=Entry(root,width=30)
zipcode.grid(row=5,column=1)

delete_box=Entry(root,width=30)
delete_box.grid(row=10,column=1)
#create text box labels
f_name_label=Label(root,text="first name",)
f_name_label.grid(row=0,column=0)

l_name_label=Label(root,text="last name",)
l_name_label.grid(row=1,column=0)

address_label=Label(root,text="address",)
address_label.grid(row=2,column=0)

city_label=Label(root,text="city",)
city_label.grid(row=3,column=0)

state_label=Label(root,text="state",)
state_label.grid(row=4,column=0)

zipcode_label=Label(root,text="zipcode",)
zipcode_label.grid(row=5,column=0)

delete_label=Label(root,text="delete",)
delete_label.grid(row=10,column=0)

#create submit button 
submit_btn=Button(root,text="add record to database",bg="red",command=submit)
submit_btn.grid(row=6,column=0,columnspan=2,pady=10,padx=10,ipadx=100)

#create a query button
query_button=Button(root,text="show records",bg="green",command=query)
query_button.grid(row=7,column=0,columnspan=2,pady=10,padx=10,ipadx=137)
#create a delete button
delete_button=Button(root,text="delete records",bg="blue",command=delete)
delete_button.grid(row=9,column=0,columnspan=2,pady=10,padx=10,ipadx=137)




#commit changes
conn.commit()

#close connection
conn.close()


root.mainloop()