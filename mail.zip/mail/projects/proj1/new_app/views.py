from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def landing_page(requests):
   return HttpResponse('new app landing page')